COKONET ACADEMY — WEBSITE (LOCAL BUILD)
=======================================

32 pages, fully cross-linked for local browsing.

START HERE:  index.html  (double-click to open in any browser)

PAGES
-----
Core (7):
  index.html ................ Homepage
  cokonet-about.html ........ About
  cokonet-careers.html ...... Careers
  cokonet-contact.html ...... Contact + FAQ
  cokonet-placements.html ... Placements & career support
  cokonet-refer.html ........ Refer & earn
  cokonet-course-sap-fico.html  SAP FICO (flagship course template)

Growth & company pages (7, new):
  cokonet-masterclass.html ......... Free 90-min live masterclass
  cokonet-scholarship.html ......... Scholarships (up to 80% off)
  cokonet-join-as-trainer.html ..... Trainer recruitment
  cokonet-jd-sap-fico-trainer.html . Open role: SAP FICO trainer
  cokonet-hire-from-us.html ........ Employer hiring page
  cokonet-alumni.html .............. Alumni stories & network
  cokonet-enterprises.html ......... Corporate training & talent

Course pages (18):
  SAP:      sap-fico, sap-mm, sap-abap, sap-successfactors
  Data/AI:  data-analytics, data-science-ai, ai-generative-ai, advanced-excel-mis
  Software: full-stack-web-development, python-programming, software-testing-qa,
            cloud-devops, cyber-security, salesforce
  Creative: digital-marketing-ai, graphic-design-ai, ui-ux-design,
            video-editing-ai-film
  Finance:  accounting-finance
  (all named cokonet-course-<slug>.html)

NAVIGATION
----------
- Header logo returns to index.html from any page.
- "All courses" mega-menu links to every course page.
- Footer course + company + employer links are wired.
- "More" dropdown: Masterclass, Scholarship, Refer, About, Alumni,
  Careers, Join as trainer, Contact (with subtitles, per design).
- "Placements" dropdown: Placements, Alumni stories, Hire from us.
- Top-nav "Enterprises" links to the enterprises page.
- Homepage course cards link to their course page.
- Every "Enrol / Syllabus / Book a call" button opens the lead popup
  (open + close + body-scroll-lock verified on all pages).
- Dark-mode toggle (moon/sun in header) persists across pages.

COURSE HERO MOTIFS (new)
------------------------
Every course hero carries a dedicated animated background motif:
film strip (video), pen paths (design), wireframes (UI/UX), rising
charts (analytics), neural nets (data science), sparkles (GenAI),
code brackets (Python), browser+tags (full stack), pass/fail marks
(QA), pipeline+containers (DevOps), hex shield (cyber), org clouds
(Salesforce), ledger+currency (FICO), conveyor crates (MM), code
scroll (ABAP), people network (SuccessFactors), calculator (finance),
spreadsheet grid (Excel), funnel arrow (marketing). All respect
prefers-reduced-motion and adapt to dark mode.

NOTES BEFORE LAUNCH (placeholder data to replace):
- Salary bands are indicative compilations, not guarantees.
- Alumni names / photos / batch dates / seat counts are placeholders.
- YouTube Shorts IDs and some logos are placeholders.
- Unresolved content conflicts (hiring-partner count, Google rating,
  placed count, founding year) still need canonical values.
